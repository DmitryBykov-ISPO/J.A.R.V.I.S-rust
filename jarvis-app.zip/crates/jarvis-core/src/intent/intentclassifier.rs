use intent_classifier::{IntentClassifier, TrainingExample, TrainingSource, IntentId, IntentFeedback};

use once_cell::sync::OnceCell;
use vosk::{DecodingState, Model, Recognizer};

use std::sync::Mutex;

static IRECOGNIZER: OnceCell<Mutex<IntentClassifier>> = OnceCell::new();

pub fn init_recognizer() {
    if IRECOGNIZER.get().is_some() {
        return;
    } // already initialized

    let mut recognizer = IntentClassifier::new().await?;

    IRECOGNIZER.set(Mutex::new(recognizer));
}
