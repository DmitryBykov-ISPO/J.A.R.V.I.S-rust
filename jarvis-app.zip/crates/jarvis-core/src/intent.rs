mod intentclassifier;

use crate::config;
use once_cell::sync::OnceCell;
use tokio::sync::OnceCell as AsyncOnceCell;

use crate::config::structs::IntentRecognitionEngine;

static IRE_TYPE: OnceCell<IntentRecognitionEngine> = OnceCell::new();
static CLASSIFIER: AsyncOnceCell<IntentClassifier> = AsyncOnceCell::const_new();

pub async fn init() -> Result<(), ()> {
    if IRE_TYPE.get().is_some() {
        return Ok(());
    } // already initialized

    // set default ire type
    // @TODO. Make it configurable?
    IRE_TYPE.set(config::DEFAULT_INTENT_RECOGNITION_ENGINE).unwrap();

    // load given recorder
    match IRE_TYPE.get().unwrap() {
        IntentRecognitionEngine::IntentClassifier => {
            // Init Intent-Classifier
            info!("Initializing Intent-Classifier IRE backend.");
            CLASSIFIER.get_or_init(|| async {
                IntentClassifier::new().await.expect("Failed to init IntentClassifier")
            }).await;
            info!("IRE backend initialized.");
        }
        IntentRecognitionEngine::Rasa => todo!(),
    }

    Ok(())
}

pub fn recognize(data: &[i16], partial: bool) -> Option<String> {
    match IRE_TYPE.get().unwrap() {
        IntentRecognitionEngine::IntentClassifier => todo!(),
        IntentRecognitionEngine::Rasa => todo!(),
    }
}
